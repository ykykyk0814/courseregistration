import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class Admin extends User implements AdminInterface, Serializable {
    public Admin() {

    }

    public Admin(String username, String password, String firstName, String lastName) {
        super(username, password, firstName, lastName);
    }

    private ArrayList<Admin> loadAdmins() throws Exception {
        ArrayList<Admin> admins = new ArrayList<>();
        BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream("data/admin.txt")));
        String line = null;
        while ((line = br.readLine()) != null) {
            String[] items = line.split(",");
            admins.add(new Admin(items[0], items[1], items[2], items[3]));
        }
        br.close();
        return admins;
    }

    @Override
    public void login(Scanner console) throws Exception {
        ArrayList<Admin> admins = loadAdmins();
        boolean loginState = false;
        while (!loginState) {
            System.out.print("please input your username: ");
            String username = console.next();
            System.out.print("please input your password: ");
            String password = console.next();
            for (Admin admin : admins) {
                if (admin.getUsername().equals(username) && admin.getPassword().equals(password)) {
                    loginState = true;
                    System.out.println("login successfully!");
                    System.out.println("hello, " + admin.getFirstName() + " " + admin.getLastName());
                    break;
                }
            }
        }
    }

    public ArrayList<Course> loadCourses() throws Exception {
        ArrayList<Course> courses = new ArrayList<>();
        BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream("data/MyUniversityCourses.csv")));
        String line = br.readLine();  // ignore first line
        while ((line = br.readLine()) != null) {
            courses.add(new Course(line));
        }
        br.close();
        return courses;
    }

    public ArrayList<Course> loadCoursesSerializable() throws Exception {
        ObjectInputStream ois = new ObjectInputStream(new FileInputStream("data/Courses.ser"));
        ArrayList<Course> courses = (ArrayList<Course>) ois.readObject();
        ois.close();
        return courses;
    }

    public void saveCourses(ArrayList<Course> courses) throws Exception {
        // read header
        BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream("data/MyUniversityCourses.csv")));
        String header = br.readLine();
        br.close();

        BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("data/MyUniversityCourses.csv")));
        // write header
        bw.write(header + "\n");
        // write content
        for (Course course : courses) {
            bw.write(course.toString() + "\n");
        }
        bw.close();
        saveCoursesSerializable(courses);
    }

    public void saveCoursesSerializable(ArrayList<Course> courses) throws Exception {
        ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("data/Courses.ser"));
        oos.writeObject(courses);
        oos.close();
    }

    @Override
    public void createCourse(Scanner console) throws Exception {
        console.nextLine(); // enter
        System.out.print("ID: ");
        String id = console.nextLine();
        System.out.print("Name: ");
        String name = console.nextLine();
        System.out.print("Max registered students: ");
        int maxRegisteredStudents = console.nextInt();
        console.nextLine(); // enter
        System.out.print("Instructor: ");
        String instructor = console.nextLine();
        System.out.print("Section number: ");
        String sectionNumber = console.nextLine();
        System.out.print("Location: ");
        String location = console.nextLine();
        Course newCourse = new Course(id, name, maxRegisteredStudents, instructor, sectionNumber, location);
        ArrayList<Course> courses = loadCourses();
        courses.add(newCourse);
        saveCourses(courses);
    }

    @Override
    public void deleteCourse(Scanner console) throws Exception {
        ArrayList<Course> courses = loadCourses();
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        for (int index = 0; index < courses.size(); index++) {
            System.out.println((index + 1) + ". " + courses.get(index).toString());
        }
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        while (true) {
            System.out.print("please input the no to delete: ");
            int choice = console.nextInt();
            if (choice >= 1 && choice <= courses.size()) {
                courses.remove(choice - 1);
                saveCourses(courses);
                break;
            }
        }
    }

    @Override
    public void editCourse(Scanner console) throws Exception {
        ArrayList<Course> courses = loadCourses();
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        for (int index = 0; index < courses.size(); index++) {
            System.out.println((index + 1) + ". " + courses.get(index).toString());
        }
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        while (true) {
            System.out.print("please input the no to edit: ");
            int choice = console.nextInt();
            if (choice >= 1 && choice <= courses.size()) {
                Course newCourse = courses.get(choice - 1);
                System.out.print("New Max registered students: ");
                newCourse.setMaxRegisteredStudents(console.nextInt());
                console.nextLine(); // enter
                System.out.print("New Instructor: ");
                newCourse.setCourseInstructor(console.nextLine());
                System.out.print("New Section number: ");
                newCourse.setCourseSectionNumber(console.nextLine());
                System.out.print("New Location: ");
                newCourse.setCourseLocation(console.nextLine());
                courses.set(choice - 1, newCourse);
                saveCourses(courses);
                break;
            }
        }
    }

    @Override
    public void displayCourse(Scanner console) throws Exception {
        ArrayList<Course> courses = loadCourses();
        console.nextLine(); // Enter
        System.out.print("ID: ");
        String id = console.nextLine();
        boolean existStatus = false;
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        for (int index = 0; index < courses.size(); index++) {
            if (courses.get(index).getCourseId().equals(id)) {
                existStatus = true;
                System.out.println(courses.get(index).toString());
            }
        }
        if (!existStatus) {
            System.out.println("Course ID " + id + " is not found!");
        }
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
    }

    @Override
    public void registerStudent(Scanner console) throws Exception {
        Student student = new Student();
        ArrayList<Student> students = student.loadStudents();
        Student newStudent = new Student();
        console.nextLine(); // Enter
        System.out.print("username: ");
        newStudent.setUsername(console.nextLine());
        System.out.print("password: ");
        newStudent.setPassword(console.nextLine());
        System.out.print("firstname: ");
        newStudent.setFirstName(console.nextLine());
        System.out.print("lastname: ");
        newStudent.setLastName(console.nextLine());
        students.add(newStudent);
        student.saveStudents(students);
    }

    @Override
    public void displayAllCourses() throws Exception {
        ArrayList<Course> courses = loadCourses();
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        for (int index = 0; index < courses.size(); index++) {
            System.out.println((index + 1) + ". " + courses.get(index).toString());
        }
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
    }

    @Override
    public void displayAllFullCourses() throws Exception {
        ArrayList<Course> courses = loadCourses();
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        int number = 1;
        for (Course course : courses) {
            if (course.getCurrentRegisteredStudents() == course.getMaxRegisteredStudents()) {
                System.out.println(number + ". " + course.toString());
                number += 1;
            }
        }
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
    }

    @Override
    public void writeAllFullCourses(Scanner console) throws Exception {
        ArrayList<Course> courses = loadCourses();
        ArrayList<Course> fullCourses = new ArrayList<>();
        for (Course course : courses) {
            if (course.getCurrentRegisteredStudents() == course.getMaxRegisteredStudents()) {
                fullCourses.add(course);
            }
        }
        // read header
        BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream("data/MyUniversityCourses.csv")));
        String header = br.readLine();
        br.close();

        System.out.print("please input file name: ");
        String fullCoursesFileName = console.next();
        BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("data/" + fullCoursesFileName + ".txt")));
        // write header
        bw.write(header + "\n");
        // write content
        for (Course course : fullCourses) {
            bw.write(course.toString() + "\n");
        }
        bw.close();
    }

    @Override
    public void displayAllStudentsByCourse(Scanner console) throws Exception {
        ArrayList<Course> courses = loadCourses();
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        for (int index = 0; index < courses.size(); index++) {
            System.out.println((index + 1) + ". " + courses.get(index).toString());
        }
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        while (true) {
            System.out.print("please input the no to display: ");
            int choice = console.nextInt();
            if (choice >= 1 && choice <= courses.size()) {
                Course course = courses.get(choice - 1);
                for (int index = 0; index < course.getRegisteredStudentNames().size(); index++) {
                    System.out.println((index + 1) + ". " + course.getRegisteredStudentNames().get(index));
                }
                break;
            }
        }
    }

    @Override
    public void displayCoursesByStudent(Scanner console) throws Exception {
        console.nextLine(); // Enter
        System.out.print("firstname: ");
        String firstname = console.nextLine();
        System.out.print("lastname: ");
        String lastname = console.nextLine();

        ArrayList<Course> courses = loadCourses();
        int number = 1;
        for (Course course : courses) {
            for (String name : course.getRegisteredStudentNames()) {
                if (name.equals(firstname + " " + lastname)) {
                    System.out.println(number + ". " + course.toString());
                    number += 1;
                }
            }
        }
    }

    @Override
    public void menu(Scanner console) throws Exception {
        while (true) {
            System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
            System.out.println("1. Courses Management");
            System.out.println("2. Reports");
            System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
            int firstLevelChoice = -1;
            while (true) {
                System.out.print("please input your choice: ");
                firstLevelChoice = console.nextInt();
                if (firstLevelChoice == 1 || firstLevelChoice == 2) {
                    break;
                }
            }
            if (firstLevelChoice == 1) {  // Courses Management
                System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                System.out.println("1. Create a new course");
                System.out.println("2. Delete a course");
                System.out.println("3. Edit a course");
                System.out.println("4. Display information for a given course");
                System.out.println("5. Register a student");
                System.out.println("6. Exit");
                System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                int secondLevelChoice = -1;
                while (true) {
                    System.out.print("please input your choice: ");
                    secondLevelChoice = console.nextInt();
                    if (secondLevelChoice >= 1 && secondLevelChoice <= 6) {
                        break;
                    }
                }
                if (secondLevelChoice == 1) {
                    createCourse(console);
                } else if (secondLevelChoice == 2) {
                    deleteCourse(console);
                } else if (secondLevelChoice == 3) {
                    editCourse(console);
                } else if (secondLevelChoice == 4) {
                    displayCourse(console);
                } else if (secondLevelChoice == 5) {
                    registerStudent(console);
                } else {
                    break;
                }
            } else {  // firstLevelChoice == 2  Reports
                System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                System.out.println("1. View all courses");
                System.out.println("2. View all courses that are FULL");
                System.out.println("3. Write to a file the list of course that are Full");
                System.out.println("4. View the names of the students being registered in a specific course");
                System.out.println("5. View the list of courses that a given student is being registered on");
                System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                int secondLevelChoice = -1;
                while (true) {
                    System.out.print("please input your choice: ");
                    secondLevelChoice = console.nextInt();
                    if (secondLevelChoice >= 1 && secondLevelChoice <= 5) {
                        break;
                    }
                }
                if (secondLevelChoice == 1) {
                    displayAllCourses();
                } else if (secondLevelChoice == 2) {
                    displayAllFullCourses();
                } else if (secondLevelChoice == 3) {
                    writeAllFullCourses(console);
                } else if (secondLevelChoice == 4) {
                    displayAllStudentsByCourse(console);
                } else {
                    displayCoursesByStudent(console);
                }
            }
        }
    }
}
