import java.util.Scanner;

public interface AdminInterface {

    void login(Scanner console) throws Exception;

    void menu(Scanner console) throws Exception;

    void createCourse(Scanner console) throws Exception;

    void deleteCourse(Scanner console) throws Exception;

    void editCourse(Scanner console) throws Exception;

    void displayCourse(Scanner console) throws Exception;

    void registerStudent(Scanner console) throws Exception;

    void displayAllCourses() throws Exception;

    void displayAllFullCourses() throws Exception;

    void writeAllFullCourses(Scanner console) throws Exception;

    void displayAllStudentsByCourse(Scanner console) throws Exception;

    void displayCoursesByStudent(Scanner console) throws Exception;
}
