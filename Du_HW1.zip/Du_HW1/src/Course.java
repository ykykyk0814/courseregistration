import java.io.Serializable;
import java.util.ArrayList;

public class Course implements Serializable {

    private String courseId;
    private String courseName;
    private int maxRegisteredStudents;
    private int currentRegisteredStudents;
    private ArrayList<String> registeredStudentNames;
    private String courseInstructor;
    private String courseSectionNumber;
    private String courseLocation;

    public Course(String courseId, String courseName, int maxRegisteredStudents,
                  String courseInstructor, String courseSectionNumber, String courseLocation
    ) {
        this.courseId = courseId;
        this.courseName = courseName;
        this.maxRegisteredStudents = maxRegisteredStudents;
        this.currentRegisteredStudents = 0;
        this.registeredStudentNames = new ArrayList<>();
        this.courseInstructor = courseInstructor;
        this.courseSectionNumber = courseSectionNumber;
        this.courseLocation = courseLocation;
    }

    public Course(String line) {
        String[] items = line.split(",");
        this.courseId = items[1];
        this.courseName = items[0];
        this.maxRegisteredStudents = Integer.parseInt(items[2]);
        this.currentRegisteredStudents = Integer.parseInt(items[3]);
        // student names: string(file) -> arraylist(object)
        if (items[4].equals("NULL")) {
            this.registeredStudentNames = new ArrayList<>();
        } else {
            String[] studentName = items[4].split(";");
            ArrayList<String> registeredStudentNames = new ArrayList<>();
            for (String name : studentName) {
                registeredStudentNames.add(name);
            }
            this.registeredStudentNames = registeredStudentNames;
        }
        this.courseInstructor = items[5];
        this.courseSectionNumber = items[6];
        this.courseLocation = items[7];
    }

    @Override
    public String toString() {
        // student names: arraylist(object) -> string(file)
        String names = "";
        if (this.registeredStudentNames.size() == 0) {
            names = "NULL";
        } else {
            for (String name : this.registeredStudentNames) {
                names = names + name + ";";
            }
            names = names.substring(0, names.length() - 1);
        }
        return this.courseName + ","
                + this.courseId + ","
                + this.maxRegisteredStudents + ","
                + this.currentRegisteredStudents + ","
                + names + ","
                + this.courseInstructor + ","
                + this.courseSectionNumber + ","
                + this.courseLocation;
    }

    public String getCourseId() {
        return courseId;
    }

    public void setCourseId(String courseId) {
        this.courseId = courseId;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public int getMaxRegisteredStudents() {
        return maxRegisteredStudents;
    }

    public void setMaxRegisteredStudents(int maxRegisteredStudents) {
        this.maxRegisteredStudents = maxRegisteredStudents;
    }

    public int getCurrentRegisteredStudents() {
        return currentRegisteredStudents;
    }

    public void setCurrentRegisteredStudents(int currentRegisteredStudents) {
        this.currentRegisteredStudents = currentRegisteredStudents;
    }

    public ArrayList<String> getRegisteredStudentNames() {
        return registeredStudentNames;
    }

    public void setRegisteredStudentNames(ArrayList<String> registeredStudentNames) {
        this.registeredStudentNames = registeredStudentNames;
    }

    public String getCourseInstructor() {
        return courseInstructor;
    }

    public void setCourseInstructor(String courseInstructor) {
        this.courseInstructor = courseInstructor;
    }

    public String getCourseSectionNumber() {
        return courseSectionNumber;
    }

    public void setCourseSectionNumber(String courseSectionNumber) {
        this.courseSectionNumber = courseSectionNumber;
    }

    public String getCourseLocation() {
        return courseLocation;
    }

    public void setCourseLocation(String courseLocation) {
        this.courseLocation = courseLocation;
    }
}
