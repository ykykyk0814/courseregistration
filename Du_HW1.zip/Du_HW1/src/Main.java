import java.util.Scanner;

public class Main {

    public static int displayLoginMenu(Scanner console) {
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        System.out.println("Welcome to Course Registration System!");
        System.out.println("1. Admin login");
        System.out.println("2. Student login");
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        while (true) {
            System.out.print("please input your choice: ");
            int choice = console.nextInt();
            if (choice == 1 || choice == 2) {
                return choice;
            }
        }
    }

    public static void main(String[] args) throws Exception {
        // login menu
        Scanner console = new Scanner(System.in);
        int user = displayLoginMenu(console);
        if (user == 1) {
            // admin login
            Admin admin = new Admin();
            admin.login(console);
            // admin menu
            admin.menu(console);
        } else {
            // student
            Student student = new Student();
            student = student.login(console);
            // student menu
            student.menu(console, student);
        }
    }
}
