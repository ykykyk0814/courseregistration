import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class Student extends User implements StudentInterface, Serializable {
    public Student() {

    }

    public Student(String username, String password, String firstName, String lastName) {
        super(username, password, firstName, lastName);
    }

    @Override
    public String toString() {
        return this.getUsername() + ","
                + this.getPassword() + ","
                + this.getFirstName() + ","
                + this.getLastName();
    }

    @Override
    public ArrayList<Student> loadStudents() throws Exception {
        ArrayList<Student> students = new ArrayList<>();
        BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream("data/student.txt")));
        String line = null;
        while ((line = br.readLine()) != null) {
            String[] items = line.split(",");
            students.add(new Student(items[0], items[1], items[2], items[3]));
        }
        br.close();
        return students;
    }

    public ArrayList<Student> loadStudentsSerializable() throws Exception {
        ObjectInputStream ois = new ObjectInputStream(new FileInputStream("data/Students.ser"));
        ArrayList<Student> students = (ArrayList<Student>) ois.readObject();
        ois.close();
        return students;
    }

    @Override
    public void saveStudents(ArrayList<Student> students) throws Exception {
        BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("data/student.txt")));
        for (Student student : students) {
            bw.write(student.toString() + "\n");
        }
        bw.close();
        saveStudentsSerializable(students);
    }

    public void saveStudentsSerializable(ArrayList<Student> students) throws Exception {
        ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("data/Students.ser"));
        oos.writeObject(students);
        oos.close();
    }

    public ArrayList<Course> loadCourses() throws Exception {
        ArrayList<Course> courses = new ArrayList<>();
        BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream("data/MyUniversityCourses.csv")));
        String line = br.readLine();  // ignore first line
        while ((line = br.readLine()) != null) {
            courses.add(new Course(line));
        }
        br.close();
        return courses;
    }

    public void saveCourses(ArrayList<Course> courses) throws Exception {
        // read header
        BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream("data/MyUniversityCourses.csv")));
        String header = br.readLine();
        br.close();

        BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("data/MyUniversityCourses.csv")));
        // write header
        bw.write(header + "\n");
        // write content
        for (Course course : courses) {
            bw.write(course.toString() + "\n");
        }
        bw.close();
    }

    @Override
    public Student login(Scanner console) throws Exception {
        ArrayList<Student> students = loadStudents();
        while (true) {
            System.out.print("please input your username: ");
            String username = console.next();
            System.out.print("please input your password: ");
            String password = console.next();
            for (Student student : students) {
                if (student.getUsername().equals(username) && student.getPassword().equals(password)) {
                    System.out.println("login successfully!");
                    System.out.println("hello, " + student.getFirstName() + " " + student.getLastName());
                    return student;
                }
            }
        }
    }

    @Override
    public void displayAllCourses() throws Exception {
        ArrayList<Course> courses = loadCourses();
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        for (int index = 0; index < courses.size(); index++) {
            System.out.println((index + 1) + ". " + courses.get(index).toString());
        }
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
    }

    @Override
    public void displayAllNotFullCourses() throws Exception {
        ArrayList<Course> courses = loadCourses();
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        int number = 1;
        for (Course course : courses) {
            if (course.getCurrentRegisteredStudents() < course.getMaxRegisteredStudents()) {
                System.out.println(number + ". " + course.toString());
                number += 1;
            }
        }
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
    }

    @Override
    public void registerCourse(Scanner console, Student student) throws Exception {
        console.nextLine();  // Enter
        System.out.print("Course name: ");
        String name = console.nextLine();
        System.out.print("Section number: ");
        String sectionNumber = console.nextLine();

        ArrayList<Course> courses = loadCourses();
        int courseIndex = -1;
        for (int index = 0; index < courses.size(); index++) {
            if (courses.get(index).getCourseName().equals(name) && courses.get(index).getCourseSectionNumber().equals(sectionNumber)) {
                courseIndex = index;
                break;
            }
        }

        if (courseIndex != -1) {
            Course course = courses.get(courseIndex);
            // currentRegisteredStudents += 1
            course.setCurrentRegisteredStudents(course.getCurrentRegisteredStudents() + 1);
            // registeredStudentNames.add(current student name)
            ArrayList<String> names = course.getRegisteredStudentNames();
            names.add(student.getFirstName() + " " + student.getLastName());
            course.setRegisteredStudentNames(names);
            courses.set(courseIndex, course);
            saveCourses(courses);
            System.out.println("Register Successfully!");
        } else {
            System.out.println("Register Failed! course name or section number is error!");
        }
    }

    @Override
    public void withdrawCourse(Scanner console, Student student) throws Exception {
        console.nextLine();  // Enter
        System.out.print("Course name: ");
        String name = console.nextLine();
        System.out.print("Section number: ");
        String sectionNumber = console.nextLine();

        ArrayList<Course> courses = loadCourses();
        int courseIndex = -1;
        for (int index = 0; index < courses.size(); index++) {
            if (courses.get(index).getCourseName().equals(name) && courses.get(index).getCourseSectionNumber().equals(sectionNumber)) {
                courseIndex = index;
                break;
            }
        }

        if (courseIndex != -1) {
            Course course = courses.get(courseIndex);
            // currentRegisteredStudents -= 1
            course.setCurrentRegisteredStudents(course.getCurrentRegisteredStudents() - 1);
            // registeredStudentNames.remove(index)
            ArrayList<String> names = course.getRegisteredStudentNames();
            names.remove(student.getFirstName() + " " + student.getLastName());
            course.setRegisteredStudentNames(names);
            courses.set(courseIndex, course);
            saveCourses(courses);
            System.out.println("Withdraw Successfully!");
        } else {
            System.out.println("Withdraw Failed! course name or section number is error!");
        }
    }

    @Override
    public void displayAllRegisterCourses(Student student) throws Exception {
        ArrayList<Course> courses = loadCourses();
        int number = 1;
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        for (Course course : courses) {
            for (String name : course.getRegisteredStudentNames()) {
                if (name.equals(student.getFirstName() + " " + student.getLastName())) {
                    System.out.println(number + ". " + course.toString());
                    number += 1;
                    break;
                }
            }
        }
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
    }

    @Override
    public void menu(Scanner console, Student student) throws Exception {
        while (true) {
            System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
            System.out.println("1. Courses Management");
            System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
            int firstLevelChoice = -1;
            while (true) {
                System.out.print("please input your choice: ");
                firstLevelChoice = console.nextInt();
                if (firstLevelChoice == 1) {
                    break;
                }
            }
            System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
            System.out.println("1. View all courses");
            System.out.println("2. View all courses that are not FULL");
            System.out.println("3. Register on a course");
            System.out.println("4. Withdraw from a course");
            System.out.println("5. View all courses that the current student is being registered in");
            System.out.println("6. Exit");
            System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
            int secondLevelChoice = -1;
            while (true) {
                System.out.print("please input your choice: ");
                secondLevelChoice = console.nextInt();
                if (secondLevelChoice >= 1 && secondLevelChoice <= 6) {
                    break;
                }
            }
            if (secondLevelChoice == 1) {
                displayAllCourses();
            } else if (secondLevelChoice == 2) {
                displayAllNotFullCourses();
            } else if (secondLevelChoice == 3) {
                registerCourse(console, student);
            } else if (secondLevelChoice == 4) {
                withdrawCourse(console, student);
            } else if (secondLevelChoice == 5) {
                displayAllRegisterCourses(student);
            } else {
                break;
            }
        }
    }
}
