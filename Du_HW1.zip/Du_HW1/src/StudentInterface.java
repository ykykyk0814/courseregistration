import java.util.ArrayList;
import java.util.Scanner;

public interface StudentInterface {

    Student login(Scanner console) throws Exception;

    ArrayList<Student> loadStudents() throws Exception;

    void saveStudents(ArrayList<Student> students) throws Exception;

    void menu(Scanner console, Student student) throws Exception;

    void displayAllCourses() throws Exception;

    void displayAllNotFullCourses() throws Exception;

    void registerCourse(Scanner console, Student student) throws Exception;

    void withdrawCourse(Scanner console, Student student) throws Exception;

    void displayAllRegisterCourses(Student student) throws Exception;
}
